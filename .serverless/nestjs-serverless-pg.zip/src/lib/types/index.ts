export interface IAPIResponse {
  data?: object | string;
  error?: object | string;
}
